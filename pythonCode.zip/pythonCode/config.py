# config.py

# Reference
# https://youtu.be/mP_Ln-Z9-XY
# Sending an Email in Python via Gmail
# LucidProgramming
# [Accessed 5 Dec 2018]


1 EMAIL_ADDRESS ="cleara59@gmail.com"
2 PASSWORD = "*********"

