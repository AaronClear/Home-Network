# camera.py
# Reference
# http://wiki.seeedstudio.com/Grove-SPDT_Relay_30A/
# [Accessed 4 Dec 2018]

from picamera import PiCamera
from time import sleep

camera = PiCamera()

# recording video

camera.start_preview()
camera.start_recording('/home/pi/video.h264')
sleep(10)
camera.stop_recording()
camera.stop_preview()


# Play the video by executing the following line of code on the command line
# omxplayer video.h264

